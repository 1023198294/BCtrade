package com.example.demo.model;


    public enum  Properties {
        QUERY_TYPE,
        EXECUTE_TYPE
    }

