package com.example.demo.model;

public enum ExCode {
    SUCCESS,
    DB_FAILURE,
    CC_FAILURE
}
